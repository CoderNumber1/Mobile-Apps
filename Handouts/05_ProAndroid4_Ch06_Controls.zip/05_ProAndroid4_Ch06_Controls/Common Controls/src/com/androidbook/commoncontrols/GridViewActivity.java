package com.androidbook.commoncontrols;

import android.app.Activity;
import android.content.CursorLoader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract.Contacts;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;

public class GridViewActivity extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.gridview);
        
        GridView gv = (GridView)findViewById(R.id.gridview);
        
        CursorLoader cloader = new CursorLoader(this, Contacts.CONTENT_URI,
        		null, null, null, Contacts.DISPLAY_NAME + " ASC");
        Cursor c = cloader.loadInBackground();

        String[] cols = new String[]{Contacts.DISPLAY_NAME};
        int[]   views = new int[]   {android.R.id.text1};
        
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,
                android.R.layout.simple_list_item_1,
                c, cols, views, SimpleCursorAdapter.NO_SELECTION);
        gv.setAdapter(adapter);
    }
}
